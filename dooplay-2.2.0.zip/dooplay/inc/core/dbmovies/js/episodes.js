jQuery(document).ready(function($) {

	// Function generate data on click
	$('#generate_data_api').click(function() {
		var ids	= $('#ids').get(0).value
		var sea	= $('#temporada').get(0).value
		var epi	= $('#episodio').get(0).value
		var dbm		= DTapi.dbm + '/app/'
		var dbmkey  = DTapi.dbmkey
		var tmdkey  = '&api_key=' + DTapi.tmdkey
		var append  = '?append_to_response=images'
		var lang	= '&language='+ DTapi.lang +'&include_image_language='+ DTapi.lang +',null'
		var tmd		= DTapi.tmd
		var pda		= DTapi.pda

		$('#api_table').addClass( "hidden_api" )
		$('#loading_api').html('<p><span class="spinner"></span> '+ DTapi.loading +'</p>')

		if( pda == 1 ) {
							$.getJSON( tmd + ids +'/season/'+ sea +'/episode/'+ epi + append + lang + tmdkey  , function(tmdbdata) {

								$('#loading_api').html('')
								$('#api_table').removeClass( "hidden_api" )

								var valPlo = "";
								var valImg = "";
								var valBac = "";
								var valupimg = "";
								$.each(tmdbdata, function(key, val) {
									$('input[name=' + key + ']').val(val);
									$('#message').remove();
									$("#verificador").show();
									$('#dt_backdrop').val(valImg);
									if (key == "vote_count") {
										$('#serie_vote_count').val(val);
									}
									if (key == "name") {
										$('#episode_name').val(val);
									}
									if (key == "vote_average") {
										$('#serie_vote_average').val(val);
									}
									if (key == "overview") {
										// si es editor visual
										if (typeof tinymce != "undefined") {
											var editor = tinymce.get('content');
											if (editor && editor instanceof tinymce.Editor) {
												editor.setContent(val);
												editor.save({
													no_events: true
												});
											} else {
												// si no es editor visual
												$('textarea#content').val(val);
											}
										}
									}
									if (key == "still_path") {
										valImg += val + "";
									}
									if (key == "still_path") {
										valupimg += "https://image.tmdb.org/t/p/w500" + val + "";
										if ( DTapi.upload == 1 ) {
											if ( DTapi.post != 'edit') {
												$('#postimagediv p').html("<ul><li><img src='" + valupimg + "'/> </li></ul>");
											}
										}
									}
									if (key == "images") {
										var imgt = "";
										$.each(tmdbdata.images.stills, function(i, item) {
											if (i > 9) return false;
											imgt += item.file_path + "\n";
										});
										$('textarea[name="imagenes"]').val(imgt);
									}
									$.getJSON( tmd + ids + '?language='+ DTapi.lang +'&include_image_language='+ DTapi.lang +',null' + tmdkey, function(tmdbdata) {
										$.each(tmdbdata, function(key, item) {
											if (key == "name") {
												$('#serie').val(item);
												$('label#title-prompt-text').addClass('screen-reader-text');
												$('input[name=post_title]').val(item + ": " + DTapi.eseas + sea + DTapi.esepart + DTapi.eepisod + epi);
											}
										});
									});

									$.getJSON( tmd + ids + '/season/' + sea + '?language=' + DTapi.lang + tmdkey, function(tmdbdata) {
										$.each(tmdbdata, function(key, item) {

											if (key == "poster_path") {
												$('#dt_poster').val(item);
											}
										});
									});

								});
							});

						}
					}
				)
});
