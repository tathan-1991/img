<?php
/*
* ----------------------------------------------------
* @author: Doothemes | Nulled by: NulledCorner
* @author URI: https://nulledcorner.com/
* @copyright: (c) 2018 Doothemes. All rights reserved
* ----------------------------------------------------
**************
* @since 2.1.7
*/
class DooPlayCache{
    // Data
    private $path;
    private $time;
    private $extn;
    // The constructor
    public function __construct(){
        // Cache data
        $this->path = WP_CONTENT_DIR.'/cache/dooplay/';
        $this->time = 86400;
        $this->extn = '.cache';
        // Verify cache folder
        if(!file_exists($this->path)) {
            mkdir($this->path, 0777, true);
        }
        if(current_user_can('manage_options')){
            add_action('admin_bar_menu', array($this,'menu'), 99);
            add_action('wp_ajax_dooplay_cache', array($this,'ajax'));
        	add_action('wp_ajax_nopriv_dooplay_cache', array($this,'ajax'));
        }
    }
    public function ajax(){
        $delet = doo_isset($_GET,'delete');
        $nonce = doo_isset($_GET,'nonce');
        if($nonce && wp_verify_nonce($nonce,'dooplay_cache_nonce')){
            switch ($delet) {
                case 'expired':
                    $this->delete_expired();
                    break;
                case 'all':
                    $this->delete_all();
                    break;
            }
        }
        wp_redirect( esc_url(doo_isset($_SERVER,'HTTP_REFERER')), 302 );
        exit;
    }
    // Menu cache
    public static function menu(){
        global $wp_admin_bar;
        $menus[] = array(
           'id'    => 'dooplay',
           'title' => __d('Dooplay options'),
           'href' => get_admin_url(get_current_blog_id(),'themes.php?page=dooplay'),
           'meta' => array(
     	        'class'  => 'dt_dooplay_menu'
            )
        );
     	$menus[] = array(
           'id'     => 'cache-expired',
           'parent' => 'dooplay',
           'title'  => __d('Delete cache expired'),
           'href'   => get_admin_url(get_current_blog_id(),'admin-ajax.php?action=dooplay_cache&delete=expired&nonce='.wp_create_nonce('dooplay_cache_nonce'))
        );
        $menus[] = array(
           'id'     => 'delete-all-cache',
           'parent' => 'dooplay',
           'title'  => __d('Delete all cache'),
           'href'   => get_admin_url(get_current_blog_id(), 'admin-ajax.php?action=dooplay_cache&delete=all&nonce='.wp_create_nonce('dooplay_cache_nonce'))
        );
        foreach( apply_filters('dooplay_cache_menu', $menus ) as $menu ){
            $wp_admin_bar->add_menu($menu);
        }
    }
    // Get data in cache
    public function get($label){
        if($this->is($label)){
			return file_get_contents($this->path.$label.$this->extn);
		}
		return false;
    }
    // Set data in cache
    public function set($label, $data){
        file_put_contents($this->path.$label.$this->extn, $data);
    }
    // Verify cache
    public function is($label){
        $filename = $this->path.$label.$this->extn;
        if(file_exists($filename) && (filemtime($filename) + $this->time >= time())) return true;
		return false;
    }
    // Delete
    public function delete($label){
        $file = $this->path.$label.$this->extn;
        if(file_exists($file)) unlink($file);
        return false;
    }
    // Delete Expired
    private function delete_expired(){
        foreach(glob("{$this->path}/*{$this->extn}") as $file){
            if(is_file($file) && (filemtime($file) + $this->time <= time())) unlink($file);
        }
    }
    // Delete all cache
    private function delete_all(){
        foreach(glob("{$this->path}/*{$this->extn}") as $file){
            if(is_file($file)) unlink($file);
        }
    }
}
new DooPlayCache;
