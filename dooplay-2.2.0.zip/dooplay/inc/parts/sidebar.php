<div class="sidebar scrolling">
	<div class="fixed-sidebar-blank">
		<?php dynamic_sidebar('sidebar-home'); ?>
	</div>
</div>
