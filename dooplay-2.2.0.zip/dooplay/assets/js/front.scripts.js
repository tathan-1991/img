
var js = {};

!function($){

    $(document).on("click","#top-page",function(){
        $("html, body").animate({ scrollTop: 0 }, "slow")
        return false
    })


    $(document).on("click","#discoverclic",function(){
		$(this).addClass("hidde")
		$("#closediscoverclic" ).removeClass("hidde")
		$("#discover").addClass( "show" )
		$("#requests").addClass( "hidde" )
		$(".requests_menu").addClass("hidde")
		$(".requests_menu_filter").removeClass("hidde")
	})


    $(document).on("click","#closediscoverclic",function(){
		$(this).addClass("hidde")
		$("#discoverclic").removeClass("hidde")
		$("#discover").removeClass("show")
		$("#requests").removeClass("hidde")
		$(".requests_menu_filter").addClass("hidde")
		$(".requests_menu").removeClass("hidde")
	})


    $(document).on("click",".filtermenu a",function(){
		var type = $(this).attr("data-type")
		$(".filtermenu a").removeClass("active")
		$(this).addClass("active")
		$("#type").val( type )
		return false
	})


    $(document).on("click",".rmenu a",function(){
		var tab_id = $(this).attr("data-tab")
		$(".rmenu a").removeClass("active")
		$(".tabox").removeClass("current")
		$(this).addClass("active")
		$("#"+tab_id).addClass("current")
		return false
	})


	$(document).on("click",".clicklogin",function(){
		$(".login_box ").show()
	})


	$(document).on("click","#c_loginbox",function(){
		$(".login_box ").hide()
	})


    $(document).on("click",".nav-resp",function(){
		$("#arch-menu").toggleClass("sidblock")
		$(".nav-resp").toggleClass("active")
	})


    $(document).on("click",".nav-advc",function(){
		$("#advc-menu").toggleClass("advcblock")
		$(".nav-advc").toggleClass("dactive")
	})


    $(document).on("click",".report-video",function(){
		$("#report-video").toggleClass("report-video-active")
		$(".report-video").toggleClass("report-video-dactive")
	})


    $(document).on("click",".adduser",function(){
		$("#register_form").toggleClass("advcblock")
		$(".form_fondo").toggleClass("advcblock")
		$(".adduser").toggleClass("dellink")
	})


    $(document).on("click",".search-resp",function(){
		$("#form-search-resp").toggleClass("formblock")
		$(".search-resp").toggleClass("active")
	})


    $(document).on("click",".wide",function(){
		$("#playex").toggleClass("fullplayer")
		$(".sidebar").toggleClass("fullsidebar")
		$(".icons-enlarge2").toggleClass("icons-shrink2")
	})


    $(document).on("click",".sources",function(){
		$(".sourceslist").toggleClass("sourcesfix")
		$(".listsormenu").toggleClass("icon-close2")
	})

    $(document).keyup(function(e) {
		if (e.keyCode == 27) {
			$(".login_box").hide( 100 )
			$("#result_edit_link").hide( 100 )
			$("#report-video").removeClass("report-video-active")
		}
	})


    var owlSliders = ["#tvload", "#movload", "#featload", "#epiload", "#seaload", "#slallload", "#sltvload", "#slmovload",".genreload"]
    $.each(owlSliders, function(index, value){
        if($(value).length >= 1){
            $(".content").ready(function(){
        		$(value).css("display","none")
        	})
        	$(".content").load(function(){
        		$(value).css("display","none")
        	})
        }
    })


    for(var a = 0, b = $(".items .item"),
        c = 0; c <= b.length; c++) a > 3 ? ($(".items .item:nth-child(" + c + ") .dtinfo")
		.addClass("right"), 5 > a ? a++ : (a--, a--, a--, a--)) : (
		$(".items .item:nth-child(" + c + ") .dtinfo").addClass("left"), a++
	)


    $.fn.exists = function() {
        return a(this).length > 0
    },

    js.model = {
        events: {},
        extend: function(b) {
            var c = $.extend({}, this, b);
            return $.each(c.events, function(a, b) {
                c._add_event(a, b)
            }), c
        },
        _add_event: function(b, c) {
            var d = this,
                e = b,
                f = "",
                g = document;
            b.indexOf(" ") > 0 && (e = b.substr(0, b.indexOf(" ")), f = b.substr(b.indexOf(" ") + 1)), "resize" != e && "scroll" != e || (g = window), $(g).on(e, f, function(b) {
                b.$el = $(this), "function" == typeof d.event && (b = d.event(b)), d[c].apply(d, [b])
            })
        }
    },

    js.header = js.model.extend({
        $header: null,
        $sub_header: null,
        active: 0,
        hover: 0,
        show: 0,
        y: 0,
        opacity: 1,
        direction: "down",
        events: {
            ready: "ready",
            scroll: "scroll",
            "mouseenter #header": "mouseenter",
            "mouseleave #header": "mouseleave"
        },
        ready: function() {
            this.$header = $("#header"), this.$sub_header = $("#sub-header"), this.active = 1
        },
        mouseenter: function() {
            var b = $(window).scrollTop();
            this.hover = 1, this.opacity = 1, this.show = b, this.$header.stop().animate({
                opacity: 1
            }, 250)
        },
        mouseleave: function() {
            this.hover = 0
        },
        scroll: function() {
            if (this.active) {
                var b = $(window).scrollTop(),
                    c = b >= this.y ? "down" : "up",
                    d = c !== this.direction,
                    f = (b - this.y, this.$sub_header.outerHeight());
                clearTimeout(this.t), 70 > b && this.$header.removeClass("-white"), d && (0 == this.opacity && "up" == c ? (this.show = b, f > b ? this.show = 0 : this.show -= 70) : 1 == this.opacity && "down" == c && (this.show = b), this.show = Math.max(0, this.show)), this.$header.hasClass("-open") && (this.show = b), this.hover && (this.show = b);
                var g = b - this.show;
                g = Math.max(0, g), g = Math.min(g, 70);
                var h = (70 - g) / 70;
                this.$header.css("opacity", h), b > f ? this.$header.addClass("-white") : 0 == h && this.$header.removeClass("-white"), this.y = b, this.direction = c, this.opacity = h
            }
        }
    })
}(jQuery);
