!function(a){
    var DooLinks = {}
    a(function(){
        DooLinks.Load()
    })
    DooLinks.Load = function(){
        var CountID = "#counter"
        if(a(CountID).length == 1){
            var Seconds
                Seconds = a(CountID).text()
                Seconds = parseInt(Seconds, 10)
                TheLink = a("#link").attr("href")
            if(Seconds === 0) {
                switch(Link.exit) {
                    case "btn":
                        a(".counter").remove()
                        a(".text").fadeIn(2000)
                        a("#link").fadeIn(700)
                        break
                    case "clo":
                        window.location.replace(TheLink)
                        break
                }
                return
            }
            Seconds--
            a(CountID).html(Seconds)
            setTimeout(DooLinks.Load, 1000)
        }
    }
}(jQuery)
